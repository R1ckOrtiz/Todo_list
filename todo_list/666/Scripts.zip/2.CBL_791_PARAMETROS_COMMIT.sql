--------------------------------------------------------------------------------
-- CBL - RUMO
-- Vers�o..........: 791
-- Objetivo........: Limites ME, Travess�o TEX, Terceirinha TIQ, Fringe (ZJA,ZFR) e Maq
-- Data............: 19/10/2026
-- Desenvolvido por: Equipe Malha
--------------------------------------------------------------------------------

-- Alterar Se��o para Owner Correspondente
ALTER SESSION SET CURRENT_SCHEMA=ATWPRD;

--
--------------------------------------------------------------------------------
-- Companhia: RUMO -- MALHA NORTE (RAILWAY_ID = 1)
--------------------------------------------------------------------------------
INSERT INTO CBL_BLOQUEIO_VERSAO (NUMERO_VERSAO, TIPO_VERSAO, RAILWAY_ID, DATA_INICIO_ALERTA, DATA_LIMITE_VERSAO, DTHR_TIMESTAMP)
VALUES (790, 'MALHA',     1, '02/11/2026', '02/11/2026', SYSDATE);

INSERT INTO CBL_BLOQUEIO_VERSAO (NUMERO_VERSAO, TIPO_VERSAO, RAILWAY_ID, DATA_INICIO_ALERTA, DATA_LIMITE_VERSAO, DTHR_TIMESTAMP)
VALUES (790, 'MALHA_RDC', 1, '02/11/2026', '02/11/2026', SYSDATE);

--------------------------------------------------------------------------------
-- Companhia: RUMO -- MALHA SUL   (RAILWAY_ID = 2)
--------------------------------------------------------------------------------
INSERT INTO CBL_BLOQUEIO_VERSAO (NUMERO_VERSAO, TIPO_VERSAO, RAILWAY_ID, DATA_INICIO_ALERTA, DATA_LIMITE_VERSAO, DTHR_TIMESTAMP)
VALUES (790, 'MALHA',     2, '02/11/2026', '02/11/2026', SYSDATE);

--
--------------------------------------------------------------------------------
-- FIM --
--------------------------------------------------------------------------------