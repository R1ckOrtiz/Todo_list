--------------------------------------------------------------------------------
-- CBL - RUMO
-- Vers�o..........: 791
-- Objetivo........: Limites ME, Travess�o TEX, Terceirinha TIQ, Fringe (ZJA,ZFR) e Maq
-- Data............: 03/11/2026
-- Desenvolvido por: Equipe Malha
--------------------------------------------------------------------------------

-- Alterar Se��o para Owner Correspondente
ALTER SESSION SET CURRENT_SCHEMA=ATWPRD;

--
--------------------------------------------------------------------------------
-- Companhia: RUMO --
-- Vers�o CBL: 2800 / Vers�o Malha CBL: 791
--------------------------------------------------------------------------------
INSERT INTO CBL_VERSAO_MALHA (CV_ID_CV, EQ_VER_SW, EQ_VER_MALHA, CV_ST_ATIVO, CV_DT_PRD, US_ID_USR, CO_ID_CO)
       VALUES (CBL_VERSAO_MALHA_SEQ_ID.NEXTVAL,
              (SELECT MAX(EQ_VER_SW) FROM CBL_VERSAO_MALHA WHERE CO_ID_CO = (SELECT CO_ID_CO FROM COMPANY WHERE CO_DSC_CO = 'RUMO')),
              791,
              'Y',
               SYSDATE,
               1,
               (SELECT CO_ID_CO FROM COMPANY WHERE CO_DSC_CO = 'RUMO'));


--------------------------------------------------------------------------------
-- Companhia: MRS --
-- Vers�o CBL: 111 / Vers�o Malha CBL: 724
--------------------------------------------------------------------------------
INSERT INTO CBL_VERSAO_MALHA (CV_ID_CV, EQ_VER_SW, EQ_VER_MALHA, CV_ST_ATIVO, CV_DT_PRD, US_ID_USR, CO_ID_CO)
       VALUES (CBL_VERSAO_MALHA_SEQ_ID.NEXTVAL,
              (SELECT MAX(EQ_VER_SW) FROM CBL_VERSAO_MALHA WHERE CO_ID_CO = (SELECT CO_ID_CO FROM COMPANY WHERE CO_DSC_CO = 'MRS')),
               724,
               'Y',
               SYSDATE, 1,
               (SELECT CO_ID_CO FROM COMPANY WHERE CO_DSC_CO = 'MRS'));


--------------------------------------------------------------------------------
-- Companhia: RUMO RDC --
-- Vers�o Malha CBL: 791
--------------------------------------------------------------------------------
INSERT INTO CBL_VERSAO_MALHA (CV_ID_CV, EQ_VER_SW, EQ_VER_MALHA, CV_ST_ATIVO, CV_DT_PRD, US_ID_USR, CO_ID_CO)
       VALUES (CBL_VERSAO_MALHA_SEQ_ID.NEXTVAL, 
              (SELECT MAX(EQ_VER_SW) FROM CBL_VERSAO_MALHA WHERE CO_ID_CO = (SELECT CO_ID_CO FROM COMPANY WHERE CO_DSC_CO = 'RUMO RDC')),
               791,
               'Y',
               SYSDATE,
               1,
               (SELECT CO_ID_CO FROM COMPANY WHERE CO_DSC_CO = 'RUMO RDC'));

--
--------------------------------------------------------------------------------
-- FIM --
--------------------------------------------------------------------------------